# Short Cut: YouTube Video Summarizer

Paste a YouTube link, get a summary with key points.

- `index.html`: the whole front end (HTML, CSS, JS)
- `functions/api/summarize.js`: a Cloudflare Pages Function that gets the captions and summarizes them with Workers AI

## Deploy

1. **GitHub**: create a new repository (for example `yt-summarizer`) and upload all files.
   Keep the folder path `functions/api/summarize.js` exactly as it is.
2. **Cloudflare**: Workers & Pages > Create > Pages > Connect to Git > pick the repository.
   Framework preset: None. Build command: leave empty. Build output directory: `/`.
3. After the first deploy, open the project > Settings > Bindings > Add > Workers AI.
   Variable name must be `AI`. Then redeploy (Deployments > Retry deployment, or push any commit).
4. Open your `*.pages.dev` link and try a video.

Every `git push` to the main branch redeploys the site automatically.

## Good to know

- Captions are read with an unofficial YouTube endpoint. It can stop working or get blocked, so the page has a "paste the transcript" box as a fallback.
- Workers AI has a free daily allowance. If you hit it, summaries fail until it resets (or you move to a paid plan).
- To use a different model, change `MODEL` at the top of `summarize.js`.
